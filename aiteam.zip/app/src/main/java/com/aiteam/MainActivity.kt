package com.aiteam

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var chatLog: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private lateinit var minutesInput: EditText
    private lateinit var stopBtn: Button
    private lateinit var modelsBox: LinearLayout
    private lateinit var leaderView: TextView
    private lateinit var webView: WebView
    private lateinit var previewNote: TextView

    private val tabs = ArrayList<View>()
    private val tabButtons = ArrayList<Button>()
    private var shownHtml = ""
    private var dp = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        dp = resources.displayMetrics.density
        val pad = (12 * dp).toInt()

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(pad, (28 * dp).toInt(), pad, 0)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        val names = listOf("Чат", "Нейросети", "Предпросмотр")
        for (i in names.indices) {
            val b = button(names[i]) { selectTab(i) }
            b.setAllCaps(false)
            tabButtons.add(b)
            bar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        page.addView(bar)

        val chat = buildChat()
        val models = buildModels()
        val preview = buildPreview()
        tabs.add(chat)
        tabs.add(models)
        tabs.add(preview)
        for (t in tabs) {
            page.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(page)
        selectTab(0)
    }

    // ---------- вкладки ----------

    private fun buildChat(): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL

        chatLog = TextView(this)
        chatLog.textSize = 14f
        chatScroll = ScrollView(this)
        chatScroll.addView(chatLog)
        t.addView(chatScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        input = EditText(this)
        input.hint = "Вопрос или задача. Потом нажми нужную кнопку."
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.maxLines = 4
        t.addView(input)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.addView(button("Спросить всех") { ask(0) }, weight())
        row1.addView(button("Задача командой") { ask(1) }, weight())
        row1.addView(button("Улучшить") { ask(2) }, weight())
        t.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        minutesInput = EditText(this)
        minutesInput.hint = "Минут"
        minutesInput.setText("10")
        minutesInput.inputType = InputType.TYPE_CLASS_NUMBER
        minutesInput.setSingleLine()
        row2.addView(minutesInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.6f))
        row2.addView(button("Выбрать главного") { startElection() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f))
        stopBtn = button("Стоп") {
            Team.stop = true
            toast("Останавливаю...")
        }
        row2.addView(stopBtn, weight())
        t.addView(row2)
        return t
    }

    private fun buildModels(): ScrollView {
        val sv = ScrollView(this)
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.addView(label("Нейросети команды", 17f))
        leaderView = label("", 14f)
        t.addView(leaderView)
        modelsBox = LinearLayout(this)
        modelsBox.orientation = LinearLayout.VERTICAL
        t.addView(modelsBox)
        t.addView(button("Добавить нейросеть") { showAddDialog() })
        t.addView(
            label(
                "Ключи хранятся только на этом телефоне. Бесплатные ключи без карты: Gemini (aistudio.google.com/apikey), " +
                    "Groq (console.groq.com), OpenRouter (openrouter.ai), Mistral (console.mistral.ai), Cerebras (cloud.cerebras.ai). " +
                    "У бесплатных тарифов небольшие дневные лимиты, поэтому команда делает паузы. " +
                    "Подписка на чат (ChatGPT Plus, Claude Pro) ключа не даёт: для GPT и Claude нужен отдельный платный API-ключ.",
                12f
            )
        )
        sv.addView(t)
        return sv
    }

    private fun buildPreview(): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        previewNote = label("", 13f)
        t.addView(previewNote)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.setBackgroundColor(Color.WHITE)
        t.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return t
    }

    private fun selectTab(n: Int) {
        for (i in tabs.indices) {
            tabs[i].visibility = if (i == n) View.VISIBLE else View.GONE
            tabButtons[i].alpha = if (i == n) 1f else 0.5f
        }
    }

    // ---------- помощники ----------

    private fun label(t: String, size: Float): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.setOnClickListener { onClick() }
        return b
    }

    private fun weight(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- действия ----------

    private fun ask(kind: Int) {
        if (Team.running) {
            toast("Команда уже работает. Дождись или нажми «Стоп».")
            return
        }
        val q = input.text.toString().trim()
        if (kind != 2 && q.isEmpty()) {
            toast("Сначала напиши вопрос или задачу")
            return
        }
        input.setText("")
        if (kind == 0) Team.discuss(q)
        else if (kind == 1) Team.build(q)
        else Team.improve(q)
    }

    private fun startElection() {
        if (Team.running) {
            toast("Команда уже работает. Дождись или нажми «Стоп».")
            return
        }
        val m = minutesInput.text.toString().trim().toIntOrNull() ?: 10
        Team.election(m)
    }

    private fun showAddDialog() {
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        val p = (16 * dp).toInt()
        lay.setPadding(p, p, p, 0)

        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Presets.all.map { it.name })
        val nameE = EditText(this)
        nameE.hint = "Название"
        val modelE = EditText(this)
        modelE.hint = "Модель"
        val urlE = EditText(this)
        urlE.hint = "Адрес API"
        val keyE = EditText(this)
        keyE.hint = "API-ключ"
        keyE.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val noteV = label("", 12f)
        var typeNow = "openai"

        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val pr = Presets.all[position]
                nameE.setText(pr.name)
                modelE.setText(pr.model)
                urlE.setText(pr.url)
                noteV.text = pr.note
                typeNow = pr.type
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        lay.addView(sp)
        lay.addView(noteV)
        lay.addView(nameE)
        lay.addView(modelE)
        lay.addView(urlE)
        lay.addView(keyE)

        AlertDialog.Builder(this)
            .setTitle("Добавить нейросеть")
            .setView(lay)
            .setPositiveButton("Добавить") { _, _ ->
                var name = nameE.text.toString().trim()
                val key = keyE.text.toString().trim()
                val url = urlE.text.toString().trim()
                val model = modelE.text.toString().trim()
                if (name.isEmpty() || key.isEmpty() || url.isEmpty() || model.isEmpty()) {
                    toast("Заполни все поля")
                } else {
                    var n = 2
                    val base = name
                    while (Store.list().any { it.name.equals(name, true) }) {
                        name = base + " " + n
                        n++
                    }
                    Store.add(Provider(System.currentTimeMillis().toString(), name, typeNow, url, model, key))
                    refresh()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun renderModels() {
        modelsBox.removeAllViews()
        val list = Store.list()
        val lead = Store.leader()
        leaderView.text = if (lead == null) "Главный пока не выбран. Нажми «Выбрать главного» во вкладке «Чат»."
        else "Главный: " + lead.name
        if (list.isEmpty()) {
            modelsBox.addView(label("Пока никого нет. Нажми «Добавить нейросеть».", 14f))
        }
        for (p in list) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val star = if (lead != null && lead.id == p.id) "★ " else ""
            row.addView(label(star + p.name + " (" + p.model + ")", 14f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Удалить") {
                Store.remove(p.id)
                refresh()
            })
            modelsBox.addView(row)
        }
    }

    // ---------- обновление экрана ----------

    override fun onResume() {
        super.onResume()
        Team.onChange = { refresh() }
        refresh()
    }

    override fun onPause() {
        Team.onChange = null
        super.onPause()
    }

    private fun refresh() {
        val tr = Team.transcript()
        chatLog.text = if (tr.isEmpty()) "Добавь нейросети во вкладке «Нейросети», потом задай вопрос или задачу." else tr
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
        stopBtn.alpha = if (Team.running) 1f else 0.4f
        renderModels()
        val h = Team.html
        if (h != shownHtml) {
            shownHtml = h
            if (h.isNotEmpty()) webView.loadDataWithBaseURL(null, h, "text/html", "utf-8", null)
        }
        previewNote.text = if (h.isEmpty()) "Страницы пока нет. Во вкладке «Чат» напиши задачу и нажми «Задача командой»."
        else "Страница от команды. Не нравится? Во вкладке «Чат» напиши, что улучшить, и нажми «Улучшить»."
    }
}
