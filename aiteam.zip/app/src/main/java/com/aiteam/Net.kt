package com.aiteam

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Net {
    class HttpError(val code: Int, msg: String) : RuntimeException("HTTP " + code + ": " + msg)

    fun sleepStoppable(ms: Long) {
        var left = ms
        while (left > 0 && !Team.stop) {
            Thread.sleep(500)
            left -= 500
        }
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 180000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text.take(300))
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun once(p: Provider, system: String, user: String): String {
        if (p.type == "anthropic") {
            val body = JSONObject()
            body.put("model", p.model)
            body.put("max_tokens", 3000)
            body.put("system", system)
            body.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val headers = HashMap<String, String>()
            headers["x-api-key"] = p.key
            headers["anthropic-version"] = "2023-06-01"
            val resp = JSONObject(post(p.url, headers, body.toString()))
            val arr = resp.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "text") sb.append(o.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw RuntimeException("пустой ответ")
            return out
        }
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        msgs.put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject()
        body.put("model", p.model)
        body.put("messages", msgs)
        body.put("max_tokens", 3000)
        body.put("temperature", 0.7)
        val headers = HashMap<String, String>()
        headers["Authorization"] = "Bearer " + p.key
        val resp = JSONObject(post(p.url, headers, body.toString()))
        val out = resp.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim()
        if (out.isEmpty()) throw RuntimeException("пустой ответ")
        return out
    }

    /** Спрашивает нейросеть. При лимитах и перегрузке ждёт и повторяет. */
    fun ask(p: Provider, system: String, user: String): String {
        var wait = 15000L
        var last: Exception? = null
        for (attempt in 0 until 4) {
            if (Team.stop) throw RuntimeException("остановлено")
            try {
                return once(p, system, user)
            } catch (e: HttpError) {
                last = e
                if (e.code == 429 || e.code >= 500) {
                    Team.note("  " + p.name + ": лимит или перегрузка, пауза " + (wait / 1000) + " с")
                    sleepStoppable(wait)
                    wait *= 2
                } else {
                    throw e
                }
            } catch (e: IOException) {
                last = e
                Team.note("  " + p.name + ": нет связи, пауза " + (wait / 1000) + " с")
                sleepStoppable(wait)
                wait *= 2
            }
        }
        throw last ?: RuntimeException("нет ответа")
    }
}
